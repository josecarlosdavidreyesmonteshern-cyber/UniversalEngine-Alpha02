using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Drop this on an empty GameObject in a new URP scene.
/// It creates a small, readable Sun + planet demo and a minimal runtime HUD.
/// This is a prototype scene builder; replace primitive visuals with planet materials later.
/// </summary>
public class SolarSystemBootstrap : MonoBehaviour
{
    [Header("Scene")]
    public Camera sceneCamera;
    public bool createDemoSystemOnStart = true;

    private NBodySimulation simulation;
    private FreeCameraController cameraController;
    private Text status;
    private Text selectedInfo;
    private Text selectionLabel;
    private Slider timeSlider;
    private CelestialBody selectedBody;

    private void Start()
    {
        if (!createDemoSystemOnStart) return;

        EnsureCamera();
        CreateSystem();
        CreateMinimalHud();
        SelectBody(GameObject.Find("Earth")?.GetComponent<CelestialBody>());
    }

    private void EnsureCamera()
    {
        if (sceneCamera == null) sceneCamera = Camera.main;
        if (sceneCamera == null)
        {
            var cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            sceneCamera = cameraObject.AddComponent<Camera>();
            cameraObject.AddComponent<AudioListener>();
        }

        sceneCamera.transform.position = new Vector3(0, 70, -230);
        sceneCamera.transform.rotation = Quaternion.Euler(15, 0, 0);
        cameraController = sceneCamera.GetComponent<FreeCameraController>();
        if (cameraController == null)
            cameraController = sceneCamera.gameObject.AddComponent<FreeCameraController>();

        cameraController.focusPoint = Vector3.zero;
        cameraController.distance = 240f;
    }

    private void CreateSystem()
    {
        var simObject = new GameObject("Universal Engine Simulation");
        simulation = simObject.AddComponent<NBodySimulation>();
        simulation.secondsPerRealSecond = 3600f;
        simulation.maxStepSeconds = 900f;
        simulation.startPaused = false;

        CreateBody("Sun", 1.98847e30, 696340f,
            Vector3.zero, Vector3.zero, Color.white, 1f, true);

        CreateBody("Mercury", 3.3011e23, 2439.7f,
            new Vector3(57909050f, 0, 0), new Vector3(0, 0, 47.36f),
            new Color(0.55f, 0.52f, 0.48f), 18f, false);

        CreateBody("Venus", 4.8675e24, 6051.8f,
            new Vector3(108208000f, 0, 0), new Vector3(0, 0, 35.02f),
            new Color(0.85f, 0.68f, 0.42f), 14f, false);

        CreateBody("Earth", 5.9722e24, 6371f,
            new Vector3(149597870.7f, 0, 0), new Vector3(0, 0, 29.78f),
            new Color(0.16f, 0.42f, 0.88f), 12f, false);

        CreateBody("Mars", 6.4171e23, 3389.5f,
            new Vector3(227939200f, 0, 0), new Vector3(0, 0, 24.07f),
            new Color(0.72f, 0.29f, 0.17f), 18f, false);

        // Add a directional light so planets have a readable day/night side.
        var lightObject = new GameObject("Sun Light");
        var light = lightObject.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.25f;
        lightObject.transform.rotation = Quaternion.Euler(35f, -35f, 0f);

        simulation.ResetSimulation();
    }

    private void CreateBody(string bodyName, double mass, float radius,
        Vector3 positionKm, Vector3 velocityKmS, Color color,
        float visualMultiplier, bool emissive)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = bodyName;

        var body = go.AddComponent<CelestialBody>();
        body.massKg = mass;
        body.radiusKm = radius;
        body.initialPositionKm = positionKm;
        body.initialVelocityKmPerSecond = velocityKmS;
        body.visualRadiusMultiplier = visualMultiplier;
        body.ResetState();

        var renderer = go.GetComponent<Renderer>();
        var material = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        material.color = color;
        if (emissive)
        {
            material.EnableKeyword("_EMISSION");
            material.SetColor("_EmissionColor", color * 2.2f);
        }
        renderer.material = material;

        if (emissive)
        {
            var glowLight = go.AddComponent<Light>();
            glowLight.type = LightType.Point;
            glowLight.range = 35f;
            glowLight.intensity = 2f;
            glowLight.color = new Color(1f, 0.78f, 0.48f);
        }
    }

    private void CreateMinimalHud()
    {
        var canvasObject = new GameObject("Universal Engine Minimal HUD");
        var canvas = canvasObject.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObject.AddComponent<CanvasScaler>().uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        canvasObject.GetComponent<CanvasScaler>().referenceResolution = new Vector2(1920, 1080);
        canvasObject.AddComponent<GraphicRaycaster>();

        var panel = MakePanel(canvas.transform, "Top Panel",
            new Vector2(0, 1), new Vector2(1, 1), new Vector2(0, 1),
            new Vector2(0, -92), new Vector2(0, 0), new Color(0.025f, 0.045f, 0.075f, 0.82f));

        status = MakeText(panel, "UNIVERSAL ENGINE  /  SOL SYSTEM",
            28, TextAnchor.MiddleLeft, new Vector2(30, 0), new Vector2(900, 70));

        var bottom = MakePanel(canvas.transform, "Bottom Panel",
            new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 0),
            new Vector2(0, 0), new Vector2(0, 170), new Color(0.025f, 0.045f, 0.075f, 0.88f));

        selectedInfo = MakeText(bottom, "SELECTED: Earth",
            24, TextAnchor.MiddleLeft, new Vector2(28, 95), new Vector2(900, 55));

        var pause = MakeButton(bottom, "PAUSE", new Vector2(28, 22), new Vector2(180, 58),
            () => simulation.TogglePause());

        timeSlider = MakeSlider(bottom, new Vector2(250, 28), new Vector2(430, 42));
        timeSlider.minValue = 60f;
        timeSlider.maxValue = 86400f;
        timeSlider.value = simulation.secondsPerRealSecond;
        timeSlider.onValueChanged.AddListener(v => simulation.SetTimeScale(v));

        selectionLabel = MakeText(bottom, "TIME SCALE", 18, TextAnchor.MiddleLeft,
            new Vector2(700, 22), new Vector2(240, 58));

        var hint = MakeText(canvas.transform,
            "DRAG: ORBIT CAMERA     PINCH: ZOOM     TAP A PLANET: SELECT",
            17, TextAnchor.MiddleCenter, new Vector2(0, 18), new Vector2(1000, 42));
        hint.rectTransform.anchorMin = new Vector2(0.5f, 1);
        hint.rectTransform.anchorMax = new Vector2(0.5f, 1);
        hint.color = new Color(0.78f, 0.86f, 0.96f, 0.9f);
    }

    private void Update()
    {
        if (simulation == null) return;

        if (status != null)
        {
            status.text = simulation.IsPaused
                ? "UNIVERSAL ENGINE  /  PAUSED"
                : $"UNIVERSAL ENGINE  /  SOL SYSTEM  /  {simulation.secondsPerRealSecond:0} SIM-SEC/SEC";
        }

        // Simple tap selection. UI touches are ignored.
        if (Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began)
        {
            if (EventSystem.current != null &&
                EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId))
                return;

            TrySelectAt(Input.GetTouch(0).position);
        }

#if UNITY_EDITOR || UNITY_STANDALONE
        if (Input.GetMouseButtonDown(0))
        {
            if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
                return;
            TrySelectAt(Input.mousePosition);
        }
#endif
    }

    private void TrySelectAt(Vector2 screenPosition)
    {
        Ray ray = sceneCamera.ScreenPointToRay(screenPosition);
        if (Physics.Raycast(ray, out RaycastHit hit, 10000f))
        {
            var body = hit.collider.GetComponent<CelestialBody>();
            if (body != null) SelectBody(body);
        }
    }

    private void SelectBody(CelestialBody body)
    {
        if (body == null) return;
        selectedBody = body;
        if (selectedInfo != null)
        {
            selectedInfo.text =
                $"SELECTED: {body.name}   MASS: {body.massKg:E2} kg   RADIUS: {body.radiusKm:N0} km";
        }
        if (cameraController != null)
            cameraController.Focus(body.transform.position);
    }

    private static RectTransform MakePanel(Transform parent, string objectName,
        Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot,
        Vector2 anchoredPosition, Vector2 sizeDelta, Color color)
    {
        var go = new GameObject(objectName);
        go.transform.SetParent(parent, false);
        var rect = go.AddComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.pivot = pivot;
        rect.anchoredPosition = anchoredPosition;
        rect.sizeDelta = sizeDelta;
        var image = go.AddComponent<Image>();
        image.color = color;
        return rect;
    }

    private static Text MakeText(Transform parent, string value, int size,
        TextAnchor alignment, Vector2 position, Vector2 dimensions)
    {
        var go = new GameObject("Text");
        go.transform.SetParent(parent, false);
        var rect = go.AddComponent<RectTransform>();
        rect.anchorMin = new Vector2(0, 0);
        rect.anchorMax = new Vector2(0, 0);
        rect.pivot = new Vector2(0, 0);
        rect.anchoredPosition = position;
        rect.sizeDelta = dimensions;
        var text = go.AddComponent<Text>();
        text.text = value;
        text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        text.fontSize = size;
        text.alignment = alignment;
        text.color = Color.white;
        return text;
    }

    private static Button MakeButton(Transform parent, string label,
        Vector2 position, Vector2 dimensions, UnityEngine.Events.UnityAction action)
    {
        var go = new GameObject(label + " Button");
        go.transform.SetParent(parent, false);
        var rect = go.AddComponent<RectTransform>();
        rect.anchorMin = new Vector2(0, 0);
        rect.anchorMax = new Vector2(0, 0);
        rect.pivot = new Vector2(0, 0);
        rect.anchoredPosition = position;
        rect.sizeDelta = dimensions;
        var image = go.AddComponent<Image>();
        image.color = new Color(0.12f, 0.34f, 0.56f, 1f);
        var button = go.AddComponent<Button>();
        button.onClick.AddListener(action);
        var labelText = MakeText(go.transform, label, 20, TextAnchor.MiddleCenter,
            Vector2.zero, dimensions);
        labelText.rectTransform.anchorMin = Vector2.zero;
        labelText.rectTransform.anchorMax = Vector2.one;
        labelText.rectTransform.sizeDelta = Vector2.zero;
        return button;
    }

    private static Slider MakeSlider(Transform parent, Vector2 position, Vector2 dimensions)
    {
        var go = new GameObject("Time Scale Slider");
        go.transform.SetParent(parent, false);
        var rect = go.AddComponent<RectTransform>();
        rect.anchorMin = new Vector2(0, 0);
        rect.anchorMax = new Vector2(0, 0);
        rect.pivot = new Vector2(0, 0);
        rect.anchoredPosition = position;
        rect.sizeDelta = dimensions;

        var background = go.AddComponent<Image>();
        background.color = new Color(0.15f, 0.2f, 0.28f, 1f);

        var slider = go.AddComponent<Slider>();
        slider.direction = Slider.Direction.LeftToRight;

        var fillArea = new GameObject("Fill Area");
        fillArea.transform.SetParent(go.transform, false);
        var fillRect = fillArea.AddComponent<RectTransform>();
        fillRect.anchorMin = Vector2.zero;
        fillRect.anchorMax = Vector2.one;
        fillRect.offsetMin = new Vector2(5, 5);
        fillRect.offsetMax = new Vector2(-5, -5);
        var fill = new GameObject("Fill");
        fill.transform.SetParent(fillArea.transform, false);
        var fillImage = fill.AddComponent<Image>();
        fillImage.color = new Color(0.18f, 0.62f, 0.92f, 1f);
        var fillTransform = fill.GetComponent<RectTransform>();
        fillTransform.anchorMin = Vector2.zero;
        fillTransform.anchorMax = Vector2.one;
        fillTransform.sizeDelta = Vector2.zero;

        var handleArea = new GameObject("Handle Slide Area");
        handleArea.transform.SetParent(go.transform, false);
        var handleAreaRect = handleArea.AddComponent<RectTransform>();
        handleAreaRect.anchorMin = Vector2.zero;
        handleAreaRect.anchorMax = Vector2.one;
        handleAreaRect.offsetMin = new Vector2(8, 0);
        handleAreaRect.offsetMax = new Vector2(-8, 0);
        var handle = new GameObject("Handle");
        handle.transform.SetParent(handleArea.transform, false);
        var handleImage = handle.AddComponent<Image>();
        handleImage.color = Color.white;
        var handleRect = handle.GetComponent<RectTransform>();
        handleRect.sizeDelta = new Vector2(22, 30);

        slider.fillRect = fillTransform;
        slider.handleRect = handleRect;
        slider.targetGraphic = handleImage;
        return slider;
    }
}
