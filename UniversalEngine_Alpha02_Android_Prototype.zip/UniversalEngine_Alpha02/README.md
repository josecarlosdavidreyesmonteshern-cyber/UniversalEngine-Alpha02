# UNIVERSAL ENGINE — Alpha 0.2 scene prototype

This package advances the first starter into a minimal solar-system scene builder.

## Requirements
- Unity 2022.3 LTS or Unity 6
- New 3D URP project
- Android Build Support installed (SDK, NDK, OpenJDK through Unity Hub)
- In Project Settings > Player > Active Input Handling, choose **Both** or **Input Manager (Old)** for this prototype.

## Setup
1. Create a new **3D URP** project.
2. Copy the `Assets/Scripts` folder from this package into your project's `Assets` folder.
3. Create an empty GameObject named `Universal Engine Bootstrap`.
4. Add `SolarSystemBootstrap` to it.
5. Press Play. The script creates a Sun, Mercury, Venus, Earth and Mars, a directional light, camera, and a minimal HUD.
6. Switch to Android in Build Profiles / Build Settings and configure the Android package settings before building.

## Controls
- Touch and drag with one finger: orbit camera.
- Pinch with two fingers: zoom.
- Tap a planet: select it and focus the camera.
- Pause button: pause/resume.
- Slider: change simulated seconds per real second.
- In the Unity Editor, left mouse drag orbits and mouse wheel zooms.

## Prototype status
The scene is generated at runtime. This is a code starter, not a finished APK or a fully authored Unity project.
The current HUD uses Unity's legacy `Text` UI for a compact prototype. A production UI should migrate to TextMeshPro and use safe-area-aware responsive layouts.

## Physics notes
- Gravity uses Newtonian N-body calculations and double-precision state vectors.
- Units are kilometres, kilograms, and seconds.
- The Sun/planet visual sizes are deliberately exaggerated for visibility.
- This prototype does not yet include collision response, terrain, atmospheres, real ephemerides, or relativistic physics.
- N-body cost grows approximately with the square of the number of active bodies. Keep the active local system small on Android.
