using UnityEngine;

[DisallowMultipleComponent]
public class CelestialBody : MonoBehaviour
{
    [Header("Physical properties")]
    [Min(1.0)] public double massKg = 5.9722e24;
    [Min(0.01f)] public float radiusKm = 6371f;

    [Header("Initial state")]
    public Vector3 initialPositionKm;
    public Vector3 initialVelocityKmPerSecond;

    [Header("Visuals")]
    [Min(0.01f)] public float visualRadiusMultiplier = 12f;

    public Vector3d PositionKm { get; internal set; }
    public Vector3d VelocityKmPerSecond { get; internal set; }

    internal void ResetState()
    {
        PositionKm = new Vector3d(initialPositionKm.x, initialPositionKm.y, initialPositionKm.z);
        VelocityKmPerSecond = new Vector3d(
            initialVelocityKmPerSecond.x, initialVelocityKmPerSecond.y, initialVelocityKmPerSecond.z);
        UpdateVisual();
    }

    internal void UpdateVisual()
    {
        // One Unity unit represents one million kilometres.
        transform.position = new Vector3(
            (float)(PositionKm.x / 1_000_000.0),
            (float)(PositionKm.y / 1_000_000.0),
            (float)(PositionKm.z / 1_000_000.0));

        float visualRadiusUnits = Mathf.Max(0.025f, radiusKm / 1_000_000f * visualRadiusMultiplier);
        transform.localScale = Vector3.one * visualRadiusUnits * 2f;
    }
}

public struct Vector3d
{
    public double x, y, z;
    public Vector3d(double x, double y, double z) { this.x = x; this.y = y; this.z = z; }
    public double SqrMagnitude => x * x + y * y + z * z;
    public double Magnitude => System.Math.Sqrt(SqrMagnitude);
    public static Vector3d operator +(Vector3d a, Vector3d b) => new Vector3d(a.x+b.x, a.y+b.y, a.z+b.z);
    public static Vector3d operator -(Vector3d a, Vector3d b) => new Vector3d(a.x-b.x, a.y-b.y, a.z-b.z);
    public static Vector3d operator *(Vector3d a, double b) => new Vector3d(a.x*b, a.y*b, a.z*b);
    public static Vector3d operator /(Vector3d a, double b) => new Vector3d(a.x/b, a.y/b, a.z/b);
}
