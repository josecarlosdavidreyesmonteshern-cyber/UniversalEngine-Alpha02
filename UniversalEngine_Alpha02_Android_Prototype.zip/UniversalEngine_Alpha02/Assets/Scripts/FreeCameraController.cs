using UnityEngine;

public class FreeCameraController : MonoBehaviour
{
    public float orbitSensitivity = 0.18f;
    public float zoomSensitivity = 0.01f;
    public float minDistance = 0.5f;
    public float maxDistance = 5000f;
    public Vector3 focusPoint = Vector3.zero;
    public float distance = 240f;

    private float yaw;
    private float pitch = 15f;
    private float previousPinchDistance;

    private void Start()
    {
        ApplyCamera();
    }

    private void LateUpdate()
    {
        if (Input.touchCount == 1)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Moved)
            {
                yaw += touch.deltaPosition.x * orbitSensitivity;
                pitch = Mathf.Clamp(pitch - touch.deltaPosition.y * orbitSensitivity, -85f, 85f);
            }
        }
        else if (Input.touchCount >= 2)
        {
            float pinch = Vector2.Distance(Input.GetTouch(0).position, Input.GetTouch(1).position);
            if (previousPinchDistance > 0f)
                distance = Mathf.Clamp(distance - (pinch - previousPinchDistance) * zoomSensitivity,
                    minDistance, maxDistance);
            previousPinchDistance = pinch;
        }
        else
        {
            previousPinchDistance = 0f;
#if UNITY_EDITOR || UNITY_STANDALONE
            if (Input.GetMouseButton(0))
            {
                yaw += Input.GetAxis("Mouse X") * 4f;
                pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * 4f, -85f, 85f);
            }
            distance = Mathf.Clamp(distance - Input.mouseScrollDelta.y * 2f, minDistance, maxDistance);
#endif
        }
        ApplyCamera();
    }

    private void ApplyCamera()
    {
        Quaternion rotation = Quaternion.Euler(pitch, yaw, 0f);
        transform.position = focusPoint + rotation * new Vector3(0f, 0f, -distance);
        transform.rotation = rotation;
    }

    public void Focus(Vector3 worldPosition) => focusPoint = worldPosition;
}
