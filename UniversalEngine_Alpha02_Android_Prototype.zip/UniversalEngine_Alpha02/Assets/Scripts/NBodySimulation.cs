using System.Collections.Generic;
using UnityEngine;

public class NBodySimulation : MonoBehaviour
{
    private const double G = 6.67430e-20; // km^3 / (kg * s^2)

    [Header("Simulation")]
    [Min(0.01f)] public float secondsPerRealSecond = 3600f;
    [Min(1f)] public float maxStepSeconds = 900f;
    [Min(0.000001f)] public float gravitationalSofteningKm = 1000f;
    public bool startPaused;

    public bool IsPaused { get; private set; }
    public IReadOnlyList<CelestialBody> Bodies => bodies;

    private readonly List<CelestialBody> bodies = new List<CelestialBody>();
    private Vector3d[] accelerations = new Vector3d[0];
    private Vector3d[] nextAccelerations = new Vector3d[0];

    private void Awake()
    {
        IsPaused = startPaused;
        RefreshBodies();
    }

    private void FixedUpdate()
    {
        if (IsPaused || bodies.Count == 0) return;

        double elapsed = Time.fixedDeltaTime * secondsPerRealSecond;
        int steps = Mathf.Max(1, Mathf.CeilToInt((float)(elapsed / maxStepSeconds)));
        double dt = elapsed / steps;

        for (int i = 0; i < steps; i++) IntegrateVelocityVerlet(dt);
        for (int i = 0; i < bodies.Count; i++) bodies[i].UpdateVisual();
    }

    // Re-scan after a procedural scene builder has created bodies at runtime.
    public void RefreshBodies()
    {
        bodies.Clear();
        bodies.AddRange(FindObjectsOfType<CelestialBody>());
        accelerations = new Vector3d[bodies.Count];
        nextAccelerations = new Vector3d[bodies.Count];
        for (int i = 0; i < bodies.Count; i++) bodies[i].ResetState();
        CalculateAccelerations(accelerations);
    }

    public void ResetSimulation()
    {
        RefreshBodies();
    }

    public void SetPaused(bool paused) => IsPaused = paused;
    public void TogglePause() => IsPaused = !IsPaused;
    public void SetTimeScale(float value) => secondsPerRealSecond = Mathf.Max(0.01f, value);

    private void IntegrateVelocityVerlet(double dt)
    {
        CalculateAccelerations(accelerations);
        for (int i = 0; i < bodies.Count; i++)
        {
            var b = bodies[i];
            b.PositionKm = b.PositionKm + b.VelocityKmPerSecond * dt
                + accelerations[i] * (0.5 * dt * dt);
        }

        CalculateAccelerations(nextAccelerations);
        for (int i = 0; i < bodies.Count; i++)
        {
            var b = bodies[i];
            b.VelocityKmPerSecond = b.VelocityKmPerSecond
                + (accelerations[i] + nextAccelerations[i]) * (0.5 * dt);
        }

        var swap = accelerations;
        accelerations = nextAccelerations;
        nextAccelerations = swap;
    }

    private void CalculateAccelerations(Vector3d[] output)
    {
        if (output.Length != bodies.Count) return;
        double eps2 = gravitationalSofteningKm * gravitationalSofteningKm;

        for (int i = 0; i < bodies.Count; i++)
        {
            Vector3d total = new Vector3d(0, 0, 0);
            for (int j = 0; j < bodies.Count; j++)
            {
                if (i == j) continue;
                Vector3d delta = bodies[j].PositionKm - bodies[i].PositionKm;
                double r2 = delta.SqrMagnitude + eps2;
                total += delta * (G * bodies[j].massKg / (r2 * System.Math.Sqrt(r2)));
            }
            output[i] = total;
        }
    }
}
